/*
    Copyright 2010 Spearhead Development, L.L.C. <http://www.spearheaddev.com/>
    
    This file is part of Accentuate.us.
    
    Accentuate.us is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    Accentuate.us is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with Accentuate.us. If not, see <http://www.gnu.org/licenses/>.
*/

pref('extensions.accentuateus.firstRun',                    true);
pref('extensions.accentuateus.version',                     '0');

pref('extensions.accentuateus.languages.version',           0);
pref('extensions.accentuateus.languages.locale',            'en-US');
pref('extensions.accentuateus.languages.selection-code',    'ga');
pref('extensions.accentuateus.languages.feedback-success',  false);
pref('extensions.accentuateus.languages.feedback-success-hide', false);
